package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.repo.LocationRepo;
import com.demo.repo.UsersRepo;

@SpringBootApplication
public class BlogPostApplication implements CommandLineRunner {

	@Autowired
	private LocationRepo locrepo;

	
	@Autowired
	private UsersRepo urepo;

	public static void main(String[] args) {
		SpringApplication.run(BlogPostApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		
		/*
		 * Locations l1=new Locations("pskp"); Users u1=new
		 * Users("Pooja","sravani",l1,"ps@gmail.com"); Users u2=new
		 * Users("Teja","Koganti",l1,"tk@gmail.com");
		 * 
		 * Locations l2=new Locations("lmpk"); Users u3=new
		 * Users("lakshmi","noka",l2,"nk@gmail.com"); Users u4=new
		 * Users("krishna","pama",l2,"kr@gmail.co");
		 * 
		 * l1.getUsers().add(u1); l1.getUsers().add(u2);
		 * 
		 * l2.getUsers().add(u3); l2.getUsers().add(u4);
		 * 
		 * 
		 * 
		 * 
		 * urepo.save(u1); urepo.save(u2); urepo.save(u3); urepo.save(u4);
		 * 
		 * 
		 * locrepo.save(l1); locrepo.save(l2);
		 * 
		 * 
		 */
	}

}
