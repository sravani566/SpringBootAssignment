package com.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;


import com.demo.entities.Users;

public interface UsersRepo extends JpaRepository<Users, Integer> {

}
