package com.demo.controller;

public class LocationRestController {

}
