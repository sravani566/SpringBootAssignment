package com.demo.controller;

public class PostsRestController {

}
